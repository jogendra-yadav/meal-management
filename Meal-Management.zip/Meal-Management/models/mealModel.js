const Meal = require('../mongoSchema/mmMealSchema');

//logger
const logger = require('../logger')('/models/mealModel');

exports.setMeal = (mealDetails) => {
  const meal = new Meal({
    name: mealDetails.name,
    type: mealDetails.type,
    date: mealDetails.date,
    userName: mealDetails.userName
  });

  return new Promise((resolve, reject) => {
    meal.save((err, doc) => {
      if (err) {
        logger.info(`error while created user ${err}`);
        reject(err);
      } else {
        logger.info(`Meal added ${doc._id}`);
        resolve(doc._id);
      }
    });
  }).catch(error => {
    throw error;
  });
};

exports.getUserMealForDate = (userName, type, date) => {
  return new Promise((resolve, reject) => {
    Meal.find({ userName: userName, type: type, date: date }, {}, (err, dbResponse) => {
      if (err) {
        logger.info(`error while fetching meal ${err}`);
        reject(err);
      } else {
        logger.info(`meal fetch query completed.`);
        resolve(dbResponse);
      }
    });
  }).catch(error => {
    throw error;
  });
};