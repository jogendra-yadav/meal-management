const User = require('../mongoSchema/mmUserSchema');

//logger
const logger = require('../logger')('/models/userModel');

exports.setUser = (userDetails) => {
  const user = new User({
    firstName: userDetails.firstName,
    lastName: userDetails.lastName,
    email: userDetails.email,
    userName: userDetails.userName,
    password: userDetails.password,
    phoneNumber: userDetails.phoneNumber
  });

  return new Promise((resolve, reject) => {
    user.save((err, doc) => {
      if (err) {
        logger.info(`error while created user ${err}`);
        reject(err);
      } else {
        logger.info(`User created ${doc._id}`);
        resolve(doc._id);
      }
    });
  }).catch(error => {
    throw error;
  });
};

exports.getUserByUserName = (userName) => {
  return new Promise((resolve, reject) => {
    User.find({ userName: userName, isDeleted: false }, { _id: 0, password: 0, isDeleted: 0 }, (err, dbResponse) => {
      if (err) {
        logger.info(`error while fetching user ${err}`);
        reject(err);
      } else {
        logger.info(`user fetch query completed.`);
        resolve(dbResponse);
      }
    });
  }).catch(error => {
    throw error;
  });
};