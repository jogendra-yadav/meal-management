//logger
const logger = require('../logger')('/controller/mealController');
const mealModel = require('../models/mealModel');
const mealHelper = require('../helpers/mealHelper');

exports.setMeal = async (req, res, next) => {
  try {
    const mealObject = req.body;
    const validationResponse = await mealHelper.validateMealMandatoryDetails(mealObject);
    
    if(validationResponse){
      res.status(400).send(validationResponse);
      return;
    }

    const meal = {
      name: mealObject.name,
      type: mealObject.type,
      userName: mealObject.userName,
      date: new Date(mealObject.date)
    };

    const mealResponse = await mealModel.setMeal(meal);
    res.status(201).send(mealResponse);
  } catch (error) {
    logger.info(`Error: ${error}`);
    res.status(500).send(`Internal server error.`);
  };
};