//logger
const logger = require('../logger')('/controller/userController');
const userModel = require('../models/userModel');
const userHelper = require('../helpers/userHelper');
const md5 = require('md5');

exports.setUser = async (req, res, next) => {
  try {
    const userObject = req.body;
    const validationResponse = await userHelper.validateUserMandatoryDetails(userObject);
    
    if(validationResponse){
      res.status(400).send(validationResponse);
      return;
    }

    const user = {
      firstName: userObject.firstName,
      lastName: userObject.lastName,
      userName: userObject.userName,
      password: md5(userObject.password)
    };

    const userResponse = await userModel.setUser(user);
    res.status(201).send(userResponse);
  } catch (error) {
    logger.info(`Error: ${error}`);
    res.status(500).send(`Internal server error.`);
  };
};