var express = require('express');
var router = express.Router();
const mealController = require('../conrtollers/mealController');
// const auth = require('../middleware/auth');

/* GET users listing. */
router.post('/create', mealController.setMeal);

module.exports = router;