var express = require('express');
var router = express.Router();
const userController = require('../conrtollers/userController');
const auth = require('../middleware/auth');

/* GET users listing. */
router.post('/create', userController.setUser);

module.exports = router;