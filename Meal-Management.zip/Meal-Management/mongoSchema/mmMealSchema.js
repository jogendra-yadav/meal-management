//Require Mongoose
var mongoose = require('mongoose');

//Define a schema
var Schema = mongoose.Schema;

var mmMealSchema = new Schema({
  name: { type: String, index: true },
  type: { type: String },
  userName: { type: String },
  date: { type: Date }
}, {
  versionKey: false // You should be aware of the outcome after set to false
});

module.exports = mongoose.model('MMMeal', mmMealSchema, 'MMMeal');