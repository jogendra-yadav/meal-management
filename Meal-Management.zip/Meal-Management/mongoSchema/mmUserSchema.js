//Require Mongoose
var mongoose = require('mongoose');

//Define a schema
var Schema = mongoose.Schema;

var mmUserSchema = new Schema({
  userName: { type: String, index: true },
  firstName: { type: String, index: true },
  lastName: { type: String, index: true },
  password: { type: String },
  isDeleted: { type: Boolean, default: false },
}, {
  versionKey: false // You should be aware of the outcome after set to false
});

module.exports = mongoose.model('MMUser', mmUserSchema, 'MMUser');