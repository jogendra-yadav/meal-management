const winston = require('winston');

module.exports = () => {
    return winston.createLogger({
        level: 'info',
        transports: [
            new winston.transports.Console(),
            new winston.transports.File({ filename: 'combined.log' })
        ]
    });
};