//Import the mongoose module
const mongoose = require('mongoose');

//logger
const logger = require('../logger')('/config/mongoDBConnection');

//Set up default mongoose connection
const mongoDbUrl = process.env.MONGO_CONNECTION_STRING;
// console.log(process.env);
mongoose.Promise = global.Promise;
let isConnected;

exports.createConnection = () => {
  if (isConnected) {
    logger.info('=> using existing database connection');
    return Promise.resolve();
  }

  logger.info('=> using new database connection');
  return mongoose.connect(mongoDbUrl)
    .then(db => { 
      isConnected = db.connections[0].readyState;
    }).catch(error => {
        logger.info(`error while connecting to MongoDB : ${error}`);
    });
};