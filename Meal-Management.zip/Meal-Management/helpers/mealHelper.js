const logger = require('../logger')('/helper/loginHelper');
const userModel = require('../models/userModel');
const mealModel = require('../models/mealModel');

exports.validateMealMandatoryDetails = async (mealObject) => {
    try{
        if(!Object(mealObject).hasOwnProperty('name') || mealObject.name.trim() === ''){
            return { errorMessage: 'Invalid name.', invaidField: 'name' };
        }

        if(!Object(mealObject).hasOwnProperty('type') || mealObject.type.trim() === '' || ['lunch', 'dinner'].indexOf(mealObject.type) == -1){
            return { errorMessage: 'Invalid type.', invaidField: 'type' };
        }
        
        if(!Object(mealObject).hasOwnProperty('userName') || mealObject.userName.trim() === ''){
            return { errorMessage: 'Invalid userName.', invaidField: 'userName' };
        }

        if(!Object(mealObject).hasOwnProperty('date') || mealObject.date.trim() === ''){
            return { errorMessage: 'Invalid date.', invaidField: 'date' };
        }

        //check userName already exist
        const existingUserByUserName = await userModel.getUserByUserName(mealObject.userName);
        if(!existingUserByUserName.length){
            return { errorMessage: 'Invalid User', invaidField: 'userName' };
        }

        //check user meal already exist
        const existingUserMeal = await mealModel.getUserMealForDate(mealObject.userName, mealObject.type, new Date(mealObject.date));
        if(existingUserMeal.length){
            return { errorMessage: 'User meal already added for selected time slot', invaidField: 'time slot' };
        }

        return null;
    }catch(error){
        throw error;
    }
};