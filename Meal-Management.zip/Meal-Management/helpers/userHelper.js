const logger = require('../logger')('/helper/loginHelper');
const userModel = require('../models/userModel');

exports.validateUserMandatoryDetails = async (userObject) => {
    try{
        if(!Object(userObject).hasOwnProperty('firstName') || userObject.firstName.trim() === ''){
            return { errorMessage: 'Invalid firstName.', invaidField: 'firstName' };
        }

        if(!Object(userObject).hasOwnProperty('lastName') || userObject.lastName.trim() === ''){
            return { errorMessage: 'Invalid lastName.', invaidField: 'lastName' };
        }

        if(!Object(userObject).hasOwnProperty('userName') || userObject.userName.trim() === ''){
            return { errorMessage: 'Invalid userName.', invaidField: 'userName' };
        }

        if(!Object(userObject).hasOwnProperty('password') || userObject.password.trim() === ''){
            return { errorMessage: 'Invalid password.', invaidField: 'password' };
        }

        if(!Object(userObject).hasOwnProperty('confirmPassword') || userObject.confirmPassword.trim() === ''){
            return { errorMessage: 'Invalid confirmPassword.', invaidField: 'confirmPassword' };
        }

        if(userObject.confirmPassword != userObject.password){
            return { errorMessage: 'password and confirmPassword is not matched.', invaidField: 'password & confirmPassword' };
        }

        //check userName already exist
        const existingUserByUserName = await userModel.getUserByUserName(userObject.userName);
        if(existingUserByUserName.length){
            return { errorMessage: 'userName is already register. Please use different userName.', invaidField: 'userName' };
        }

        return null;
    }catch(error){
        throw error;
    }
};